import java.net.*;
import java.io.*;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;

public class SSLServer
{
    public static void main(String args[]) throws Exception
    {
        try{
                 SSLServerSocketFactory factory=(SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
                 SSLServerSocket sslserversocket=(SSLServerSocket) factory.createServerSocket(1234);
        
                SSLSocket sslsocket=(SSLSocket) sslserversocket.accept();
        
                 System.out.println("connection establised Between Chat server and Client");
                BufferedReader kb = new BufferedReader(new InputStreamReader(System.in));
                BufferedReader br = new BufferedReader(new InputStreamReader(sslsocket.getInputStream()));
                DataOutputStream dos = new DataOutputStream(sslsocket.getOutputStream());

                while(true)
                {
                    String s2,s3; 
                    while((s2=br.readLine())!=null)
                    {
                        System.out.println("Client said : "+s2);
    
                         s3 = kb.readLine();
                        //System.out.println("Answer send to client machine");
                         dos.writeBytes(s3+ " id:10638105"+ "\n" );
                    }
                }

                 
           }      
        catch(IOException e)
         {
             System.out.print(e);
         }
		
    }
}