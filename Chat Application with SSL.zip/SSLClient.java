import java.net.*;
import java.io.*;
import java.util.*;
import javax.net.*;
import javax.net.ssl.*;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.IOException;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import java.net.*;
import java.io.*;
import java.util.*;
import javax.net.*;
import javax.net.ssl.*;



public class SSLClient {
    public static void main(String args[])
    {
        try
        {
        
        SSLSocketFactory factory=(SSLSocketFactory) SSLSocketFactory.getDefault();
        SSLSocket sslsocket=(SSLSocket) factory.createSocket("192.168.1.102",1234);

        
	BufferedReader kb = new BufferedReader(new InputStreamReader(System.in));
	BufferedReader br = new BufferedReader(new InputStreamReader(sslsocket.getInputStream()));
	DataOutputStream dos = new DataOutputStream(sslsocket.getOutputStream());
 
	System.out.println(" Enter text..");
	System.out.println(" if client 'quit' type  exit");
	  
	String s1,s4=null; 
	while(!(s1=kb.readLine()).equals("exit"))
	{
		//System.out.println(" data  send to server machine");
	 	dos.writeBytes(s1+" id:10638105"+"\n");
		
		
		s4 = br.readLine();
		//System.out.println(" data  receive from  server machine");
		System.out.println("Server said : "+s4);
		
		
	}
	System.out.println("Terminated..");
        dos.close();
        kb.close();
        sslsocket.close();
        }
        catch(UnknownHostException e)
        {
             System.out.println(e.getMessage());
        }
        catch(IOException e)
        {
            System.out.println(e.getMessage());
        }
    }
}